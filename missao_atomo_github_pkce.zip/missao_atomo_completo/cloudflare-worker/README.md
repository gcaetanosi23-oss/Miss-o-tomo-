# Cloudflare Worker — autenticação do Missão Átomo

Este Worker faz a troca server-to-server do authorization code GitHub, valida a lista de professores e devolve uma sessão assinada de curta duração. O access token GitHub e o Client Secret nunca chegam ao navegador.

## Pré-requisitos
- Conta Cloudflare com Workers habilitado.
- OAuth App GitHub existente com PKCE suportado (S256).
- GitHub Pages publicado e URL final conhecida.

## Configuração
1. Edite `wrangler.toml`: `ALLOWED_ORIGIN`, `REDIRECT_URI` e `ALLOWED_TEACHERS`.
2. Instale Wrangler: `npm install -g wrangler`.
3. Entre: `wrangler login`.
4. Na pasta `cloudflare-worker`, cadastre o segredo OAuth: `npx wrangler secret put GITHUB_CLIENT_SECRET`. Cole o Client Secret no prompt do terminal; nunca o coloque em arquivos do projeto.
5. Gere um segredo de sessão aleatório e cadastre: `npx wrangler secret put SESSION_SIGNING_SECRET`. Use uma string aleatória forte (pelo menos 32 bytes).
6. Publique: `npx wrangler deploy`.
7. Copie a URL `https://...workers.dev` exibida e configure `workerUrl` em `auth-config.js`.

## OAuth App no GitHub
- Homepage URL: URL pública do GitHub Pages.
- Authorization callback URL: valor exato de `REDIRECT_URI`, por exemplo `https://SEU-USUARIO.github.io/missao-atomo/oauth-callback.html`.
- O fluxo usa `read:user`, `state` e PKCE S256.
- O Device Flow pode permanecer habilitado na configuração, mas não é utilizado pelo site.

## Teste
Abra `https://SEU-WORKER.workers.dev/health` a partir da origem autorizada para teste no navegador; a rota exige Origin igual a `ALLOWED_ORIGIN`. Faça o login no painel e confirme que contas fora de `ALLOWED_TEACHERS` recebem 403.

## Limites de segurança
A sessão assinada expira em quatro horas e é guardada em `sessionStorage`. O Worker valida a assinatura em cada consulta de sessão. O painel apresenta dados locais do navegador; isso não sincroniza resultados entre dispositivos. Para dados pedagógicos compartilhados ou sensíveis, implemente persistência e autorização no backend, não apenas no HTML/JavaScript.
