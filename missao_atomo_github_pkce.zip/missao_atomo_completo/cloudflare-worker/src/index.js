const JSON_HEADERS = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };

function corsHeaders(request, env) {
  const origin = request.headers.get("Origin") || "";
  if (origin !== env.ALLOWED_ORIGIN) return null;
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Authorization, Content-Type, Accept",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}
function json(data, status, cors = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...cors } });
}
function b64url(input) {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let binary = ""; bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
async function sign(payload, secret) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const data = b64url(JSON.stringify(payload));
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  return `${data}.${b64url(sig)}`;
}
async function verify(token, secret) {
  if (!token || token.length > 4096) return null;
  const parts = token.split("."); if (parts.length !== 2) return null;
  try {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    const sigText = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const sig = Uint8Array.from(atob(sigText + "=".repeat((4 - sigText.length % 4) % 4)), c => c.charCodeAt(0));
    const valid = await crypto.subtle.verify("HMAC", key, sig, new TextEncoder().encode(parts[0]));
    if (!valid) return null;
    const payloadText = parts[0].replace(/-/g, "+").replace(/_/g, "/");
    const payload = JSON.parse(atob(payloadText + "=".repeat((4 - payloadText.length % 4) % 4)));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch (_) { return null; }
}
function allowedTeachers(env) {
  return (env.ALLOWED_TEACHERS || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
}
async function exchange(request, env, cors) {
  let body;
  try { body = await request.json(); } catch (_) { return json({ error: "Corpo JSON inválido." }, 400, cors); }
  const { code, code_verifier, redirect_uri } = body || {};
  if (typeof code !== "string" || code.length < 8 || code.length > 256 ||
      typeof code_verifier !== "string" || code_verifier.length < 43 || code_verifier.length > 128 ||
      redirect_uri !== env.REDIRECT_URI) {
    return json({ error: "Parâmetros OAuth inválidos." }, 400, cors);
  }
  const tokenResponse = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: new URLSearchParams({
      client_id: env.GITHUB_CLIENT_ID,
      client_secret: env.GITHUB_CLIENT_SECRET,
      code,
      redirect_uri: env.REDIRECT_URI,
      code_verifier
    })
  });
  const tokenData = await tokenResponse.json().catch(() => ({}));
  if (!tokenResponse.ok || !tokenData.access_token) {
    return json({ error: tokenData.error_description || tokenData.error || "GitHub recusou a troca do código OAuth." }, 401, cors);
  }
  // O access token GitHub permanece exclusivamente no Worker e nunca é retornado ao navegador.
  const profileResponse = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "Missao-Atomo" }
  });
  const profile = await profileResponse.json().catch(() => ({}));
  if (!profileResponse.ok || !profile.login) return json({ error: "Não foi possível validar o perfil GitHub." }, 401, cors);
  if (!allowedTeachers(env).includes(String(profile.login).toLowerCase())) {
    return json({ error: `A conta @${profile.login} não está autorizada como professor.` }, 403, cors);
  }
  const now = Math.floor(Date.now() / 1000);
  const sessionToken = await sign({
    sub: String(profile.id), login: profile.login,
    name: profile.name || profile.login,
    avatar_url: profile.avatar_url || "",
    iat: now, exp: now + 4 * 60 * 60
  }, env.SESSION_SIGNING_SECRET);
  return json({ session_token: sessionToken, user: { id: profile.id, login: profile.login, name: profile.name || profile.login, avatar_url: profile.avatar_url || "" } }, 200, cors);
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = corsHeaders(request, env);
    if (!cors) return json({ error: "Origem não autorizada." }, 403);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/health" && request.method === "GET") return json({ ok: true, service: "missao-atomo-auth" }, 200, cors);
    if (url.pathname === "/oauth/exchange" && request.method === "POST") return exchange(request, env, cors);
    if (url.pathname === "/session" && request.method === "GET") {
      const match = (request.headers.get("Authorization") || "").match(/^Bearer\s+(.+)$/i);
      const session = match ? await verify(match[1], env.SESSION_SIGNING_SECRET) : null;
      if (!session) return json({ error: "Sessão inválida ou expirada." }, 401, cors);
      return json({ user: { id: session.sub, login: session.login, name: session.name, avatar_url: session.avatar_url } }, 200, cors);
    }
    return json({ error: "Endpoint não encontrado." }, 404, cors);
  }
};
