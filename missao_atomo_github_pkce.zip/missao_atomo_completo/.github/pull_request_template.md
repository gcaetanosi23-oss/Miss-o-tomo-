## O que foi alterado?

Descreva objetivamente as mudanças.

## Como testar?

- [ ] Menu principal
- [ ] Quiz – Distribuição Eletrônica
- [ ] Orbitais Quest
- [ ] Salvamento e recuperação dos slots
- [ ] Painel do professor (se aplicável)
- [ ] Responsividade em celular

## Issue relacionada

Closes #

## Observações / limitações

Informe riscos, decisões técnicas ou pontos que precisam de revisão.
